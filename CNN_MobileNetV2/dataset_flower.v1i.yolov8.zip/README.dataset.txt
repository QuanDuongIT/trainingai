# dataset_flower > 2024-10-02 10:32am
https://universe.roboflow.com/newproject-wl6ci/dataset_flower

Provided by a Roboflow user
License: CC BY 4.0

